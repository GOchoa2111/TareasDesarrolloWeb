export interface Estudiante {
}
