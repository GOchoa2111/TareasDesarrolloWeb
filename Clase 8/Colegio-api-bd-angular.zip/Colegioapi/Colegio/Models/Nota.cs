﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Colegio.Models
{
    public class Nota
    {
        [Key]  // 👈 clave primaria explícita
        public int IdNota { get; set; }

        [ForeignKey("Estudiante")] // 👈 relación con estudiante
        public int IdEstudiante { get; set; }

        public string Materia { get; set; }
        public decimal Calificacion { get; set; }

        public Estudiante Estudiante { get; set; }
    }
}


