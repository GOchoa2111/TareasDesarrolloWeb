﻿using System.ComponentModel.DataAnnotations;

namespace Colegio.Models
{
    public class Estudiante
    {
        [Key]  // 👈 clave primaria explícita
        public int IdEstudiante { get; set; }

        public string Nombre { get; set; }
        public int Edad { get; set; }
        public string Grado { get; set; }

        public ICollection<Nota> Notas { get; set; }
    }
}


