﻿using Microsoft.EntityFrameworkCore;
using Colegio.Models;

namespace Colegio.Data
{
    public class ColegioContext : DbContext
    {
        public ColegioContext(DbContextOptions<ColegioContext> options) : base(options) { }

        public DbSet<Estudiante> Estudiantes { get; set; }
        public DbSet<Nota> Notas { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Estudiante>()
                        .HasKey(e => e.IdEstudiante);

            modelBuilder.Entity<Nota>()
                        .HasKey(n => n.IdNota);

            modelBuilder.Entity<Nota>()
                        .HasOne(n => n.Estudiante)
                        .WithMany(e => e.Notas)
                        .HasForeignKey(n => n.IdEstudiante);
        }
    }
}


